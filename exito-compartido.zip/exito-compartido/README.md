# Éxito Compartido — Sistema de Ahorros y Retiros

Este repositorio contiene **un sistema nuevo e independiente** que se
**vincula por URL** (no por código) con el sistema que ya tienes de
créditos y capital. El sistema de créditos/capital **no se toca**: se
sigue usando tal cual está, y este proyecto solo consume su API pública.

```
exito-compartido/
├── README.md
├── apps-script-ahorros/
│   └── Codigo.gs      ← Backend NUEVO (hoja de cálculo NUEVA)
└── admin/
    └── index.html     ← Panel administrativo de Ahorros y Retiros
```

## Arquitectura (cómo quedan vinculados los dos sistemas)

```
┌─────────────────────────────┐        HTTP (fetch / UrlFetchApp)      ┌──────────────────────────────┐
│  Sistema de CRÉDITOS Y      │ <────────────────────────────────────  │  Sistema NUEVO de AHORROS     │
│  CAPITAL (el que ya tienes) │  leer / agregar / buscar (sin tocar    │  Y RETIROS (este repositorio) │
│  Hojas: Clientes, Creditos, │  su código, solo se usa su API)        │  Hojas: Usuarios, Ahorros,     │
│  Cuotas, Pagos, Socios,     │ ─────────────────────────────────────> │  Movimientos_Ahorros,          │
│  Capital_Social             │                                        │  Accesos_Socios, Polizas,       │
└─────────────────────────────┘                                        │  Configuracion                 │
                                                                        └──────────────────────────────┘
```

- El **sistema viejo** (créditos/capital) sigue siendo la fuente de
  verdad para: `Clientes`, `Creditos`, `Cuotas`, `Pagos`, `Socios`,
  `Capital_Social`. No se le agrega ni se le quita nada.
- El **sistema nuevo** (este repo) es la fuente de verdad para:
  ahorros, retiros, contraseñas de acceso a la banca web, tipo de
  socio (capitalista/ahorrista), pólizas y configuración de tasas.
- La **cédula** es la clave que conecta ambos sistemas: cuando el
  panel nuevo necesita saber el capital o los créditos de alguien,
  llama por HTTP a la URL del sistema viejo, filtra por cédula, y
  combina esa información con sus propios datos de ahorros.

## 1. Instalar el backend nuevo (`apps-script-ahorros/Codigo.gs`)

1. Crea una **hoja de cálculo de Google nueva y vacía** (distinta a la
   del sistema de créditos).
2. Extensiones → Apps Script → pega el contenido completo de
   `apps-script-ahorros/Codigo.gs`.
3. Revisa la constante `URL_SISTEMA_CREDITOS` al inicio del archivo:
   ya tiene puesta la URL que me compartiste
   (`.../AKfycby-BrSpUIdQ.../exec`). Si esa URL cambiara algún día,
   solo actualiza esa línea.
4. Ejecuta la función `inicializarHojas` una vez (o desde el menú
   **⚙️ Ahorros y Retiros → Inicializar base de datos**). Esto crea:
   - `Usuarios` (con un admin de ejemplo:
     `admin.ahorros@exitocompartido.com` / `admin123` — cámbiala apenas
     lo publiques)
   - `Ahorros`, `Movimientos_Ahorros`, `Accesos_Socios`, `Polizas`,
     `Configuracion`
5. (Opcional) Ejecuta `crearTriggerMensualIntereses` una vez para que
   el interés de ahorros se calcule automáticamente el día 1 de cada
   mes.
6. Implementa como **aplicación web** (Implementar → Nueva
   implementación → Aplicación web → Ejecutar como "Yo" → Acceso
   "Cualquier usuario"). Copia la URL `.../exec`.
7. La primera vez que este script llame al sistema viejo con
   `UrlFetchApp`, Google te pedirá **autorizar permisos** (incluye el
   permiso de conexión a servicios externos); acéptalo.

## 2. Configurar el panel administrativo (`admin/index.html`)

Ya viene configurado con tu URL:

```js
const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycby4b-VtgoJWJxW2nfY7JWahCc2Kx3vFF5N8c16GwkLmGBaw0xOshO6-U1BaWJtPwvdM/exec";
```

Si alguna vez vuelves a implementar el Apps Script y la URL cambia,
solo actualiza esa línea en `admin/index.html`.

El panel incluye:

- **Dashboard**: saldo total en ahorros, depósitos/retiros del mes,
  cantidad de socios capitalistas vs. ahorristas
- **Crear Socio / Acceso**: eliges si el socio es **capitalista**
  (se vincula o se crea en la hoja `Socios` del sistema viejo) o
  **ahorrista** (se vincula o se crea en la hoja `Clientes` del
  sistema viejo), y le generas su contraseña de acceso a la banca web
- **Ahorros**: buscar por cédula, depositar / retirar, ver historial
- **Créditos (vista)**: información de solo lectura tomada del
  sistema viejo por cédula o en general
- **Capital (vista)**: socios capitalistas y sus movimientos de
  capital, de solo lectura (los movimientos de capital se siguen
  registrando en el sistema viejo)
- **Pólizas**: crear y listar pólizas de inversión (dato propio de
  este sistema)
- **Administradores**: crear nuevos usuarios para este panel
- **Reportes**: ahorros, pólizas, capitalistas, ahorristas
- **Configuración**: tasa de interés anual de ahorros y de pólizas,
  nombre comercial de la caja

### Lógica de intereses de ahorros
- Tasa configurable en `Configuracion → TasaAhorros` (% anual).
- Interés mensual = `saldo actual × (tasa anual / 100 / 12)`, se
  agrega como movimiento tipo `interes` y se refleja en el saldo.
- Se puede forzar manualmente desde **Configuración → "Calcular
  intereses del mes ahora"**, o dejar que corra solo con el trigger
  mensual.

## 3. Próximo paso (no incluido todavía en este repositorio)

Cuando este sistema de ahorros/retiros esté probado y funcionando,
crearemos un **repositorio aparte** solo para la **Banca en Línea**
(login con cédula + contraseña) que el socio usará para ver todo: sus
ahorros, su capital (si es capitalista), sus créditos con tabla de
amortización y sus pólizas — combinando en modo lectura la información
de ambos sistemas. El backend de este repo ya deja lista la acción
`resumen_cedula` y `login_socio` preparadas para ese momento.
